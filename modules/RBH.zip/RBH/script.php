	<!-- js -->
	<script src="../../vendors/scripts/script.js"></script>
	<script src="../../vendors/scripts/bootstrapValidator.js"></script>