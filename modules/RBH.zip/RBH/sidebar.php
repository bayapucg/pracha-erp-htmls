	<div class="left-side-bar">
		<div class="brand-logo">
			<a href="index.php">
				<img src="../../vendors/images/deskapp-logo.png" alt="">
			</a>
		</div>
		<div class="menu-block customscroll">
			<div class="sidebar-menu">
				<ul id="accordion-menu">
				<li class="dropdown">
						<a href="rbh-add-roles.php" class="dropdown-toggle">
							<span class="fa fa-home"></span><span class="mtext">Dashboards</span>
						</a>	
					</li>
					<li class="dropdown">
						<a href="rbh-add-roles.php" class="dropdown-toggle">
							<span class="fa fa-home"></span><span class="mtext">Add Roles</span>
						</a>	
					</li>
					<li class="dropdown">
						<a href="rbh-leaves.php" class="dropdown-toggle">
							<span class="fa fa-home"></span><span class="mtext">RBH Leaves</span>
						</a>	
					</li>
					<li class="dropdown">
						<a href="rbh-reports.php" class="dropdown-toggle">
							<span class="fa fa-home"></span><span class="mtext">RBH Reports</span>
						</a>	
					</li>
					<li class="dropdown">
						<a href="rbh-work-management.php" class="dropdown-toggle">
							<span class="fa fa-home"></span><span class="mtext">Work management</span>
						</a>	
					</li>
					<li class="dropdown">
						<a href="rbh-add-roles.php" class="dropdown-toggle">
							<span class="fa fa-home"></span><span class="mtext">Recruiting management</span>
						</a>	
					</li>
					<li class="dropdown">
						<a href="rbh-add-roles.php" class="dropdown-toggle">
							<span class="fa fa-home"></span><span class="mtext">Sales</span>
						</a>	
					</li>
					<li class="dropdown">
						<a href="rbh-chat.php" class="dropdown-toggle">
							<span class="fa fa-home"></span><span class="mtext">Chats</span>
						</a>	
					</li>
					<li class="dropdown">
						<a href="rbh-announcements.php" class="dropdown-toggle">
							<span class="fa fa-home"></span><span class="mtext">Announcements / Events</span>
						</a>	
					</li>
					<li class="dropdown">
						<a href="rbh-feedback.php" class="dropdown-toggle">
							<span class="fa fa-home"></span><span class="mtext">Feedback</span>
						</a>	
					</li>
					<li class="dropdown">
						<a href="rbh-ticket.php" class="dropdown-toggle">
							<span class="fa fa-home"></span><span class="mtext">Contact Inside Tech Team</span>
						</a>
					</li>
				</ul>
			</div>
		</div>
	</div>