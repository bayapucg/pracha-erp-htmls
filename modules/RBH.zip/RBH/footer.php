	<div class="footer-wrap bg-white pd-20 mb-20 border-radius-5 box-shadow">
		Copyright By Pracha Technologies Pvt Ltd.  <a href="privacypolicy.php" class="text-warning">Privacy Policy</a>
	</div>